import os
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01"

GEN_A_PATH = os.path.join(
    BASE_DIR,
    "dataset final",
    "Dataset",
    "full_qkd_dataset_realistic_50000_v2.csv"
)

GEN_B_PATH = os.path.join(
    BASE_DIR,
    "QKD_Generator_B",
    "data",
    "qkd_generator_b_filtered_testset.csv"
)

RESULTS_DIR = os.path.join(
    BASE_DIR,
    "QKD_Generator_B",
    "results",
    "domain_shift_analysis"
)

os.makedirs(RESULTS_DIR, exist_ok=True)

print("Loading datasets...")

gen_a = pd.read_csv(GEN_A_PATH)
gen_b = pd.read_csv(GEN_B_PATH)

gen_a.columns = [c.strip().lower() for c in gen_a.columns]
gen_b.columns = [c.strip().lower() for c in gen_b.columns]

# Align feature names
gen_a = gen_a.rename(columns={"latency_ms": "latency"})

features = [
    "qber",
    "photon_count",
    "latency",
    "abort_flag"
]

# ============================================================
# Summary statistics
# ============================================================

summary_rows = []

for feature in features:

    row = {
        "feature": feature,

        "generator_a_mean": gen_a[feature].mean(),
        "generator_b_mean": gen_b[feature].mean(),

        "generator_a_std": gen_a[feature].std(),
        "generator_b_std": gen_b[feature].std(),

        "generator_a_min": gen_a[feature].min(),
        "generator_b_min": gen_b[feature].min(),

        "generator_a_max": gen_a[feature].max(),
        "generator_b_max": gen_b[feature].max()
    }

    summary_rows.append(row)

summary_df = pd.DataFrame(summary_rows)

summary_path = os.path.join(
    RESULTS_DIR,
    "feature_shift_summary.csv"
)

summary_df.to_csv(summary_path, index=False)

print("\nFeature shift summary:")
print(summary_df)

# ============================================================
# Distribution comparison plots
# ============================================================

for feature in features:

    plt.figure(figsize=(10, 6))

    plt.hist(
        gen_a[feature],
        bins=60,
        alpha=0.5,
        density=True,
        label="Generator-A"
    )

    plt.hist(
        gen_b[feature],
        bins=60,
        alpha=0.5,
        density=True,
        label="Generator-B"
    )

    plt.xlabel(feature)
    plt.ylabel("Density")
    plt.title(f"{feature} Distribution Shift")

    plt.legend()

    save_path = os.path.join(
        RESULTS_DIR,
        f"{feature}_distribution_shift.png"
    )

    plt.savefig(
        save_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

print("\nDistribution plots saved.")

# ============================================================
# Class-wise comparison
# ============================================================

class_summary = []

classes = [
    "normal",
    "partial_intercept_resend",
    "detector_blind",
    "fiber_tap"
]

for cls in classes:

    a_cls = gen_a[gen_a["label"] == cls]
    b_cls = gen_b[gen_b["label"] == cls]

    for feature in features:

        class_summary.append({
            "class": cls,
            "feature": feature,

            "generator_a_mean": a_cls[feature].mean(),
            "generator_b_mean": b_cls[feature].mean(),

            "generator_a_std": a_cls[feature].std(),
            "generator_b_std": b_cls[feature].std()
        })

class_summary_df = pd.DataFrame(class_summary)

class_summary_path = os.path.join(
    RESULTS_DIR,
    "classwise_feature_shift.csv"
)

class_summary_df.to_csv(class_summary_path, index=False)

print("\nClass-wise shift analysis saved.")

print("\nResults saved to:")
print(RESULTS_DIR)