import os
import pandas as pd

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01\QKD_Generator_B"

INPUT_PATH = os.path.join(BASE_DIR, "data", "qkd_generator_b_v2_calibrated.csv")
OUTPUT_PATH = os.path.join(BASE_DIR, "data", "qkd_generator_b_v2_filtered_testset.csv")

df = pd.read_csv(INPUT_PATH)

allowed_classes = [
    "normal",
    "partial_intercept_resend",
    "detector_blind",
    "fiber_tap"
]

filtered_df = df[df["label"].isin(allowed_classes)].copy()
filtered_df.to_csv(OUTPUT_PATH, index=False)

print("Generator-B v2 filtered test set created.")
print("Saved to:", OUTPUT_PATH)
print("Shape:", filtered_df.shape)
print("\nClass distribution:")
print(filtered_df["label"].value_counts())