import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01\QKD_Generator_B"

RESULTS_DIR = os.path.join(BASE_DIR, "results")
OUTPUT_DIR = os.path.join(RESULTS_DIR, "robustness_comparison")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================
# Accuracy Summary Table
# ============================================================

summary_df = pd.DataFrame([
    {
        "Experiment": "Internal Generator-A Validation",
        "RandomForest": 0.9710,
        "XGBoost": 0.9600
    },
    {
        "Experiment": "Cross-Generator B v1 Extreme Shift",
        "RandomForest": 0.2591,
        "XGBoost": 0.2451
    },
    {
        "Experiment": "Cross-Generator B v2 Calibrated Shift",
        "RandomForest": 0.3358,
        "XGBoost": 0.2856
    }
])

summary_path = os.path.join(
    OUTPUT_DIR,
    "robustness_accuracy_summary.csv"
)

summary_df.to_csv(summary_path, index=False)

print("Saved:", summary_path)

# ============================================================
# Robustness Accuracy Plot
# ============================================================

plt.figure(figsize=(10, 6))

x = range(len(summary_df))

plt.plot(
    x,
    summary_df["RandomForest"],
    marker="o",
    linewidth=3,
    label="Random Forest"
)

plt.plot(
    x,
    summary_df["XGBoost"],
    marker="s",
    linewidth=3,
    label="XGBoost"
)

plt.xticks(
    x,
    summary_df["Experiment"],
    rotation=10
)

plt.ylabel("Accuracy")
plt.ylim(0, 1.05)

plt.title("Cross-Generator Robustness Comparison")

plt.grid(True, linestyle="--", alpha=0.5)
plt.legend()

plot_path = os.path.join(
    OUTPUT_DIR,
    "robustness_accuracy_comparison.png"
)

plt.savefig(
    plot_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Saved:", plot_path)

# ============================================================
# Load Confusion Matrices
# ============================================================

rf_cm_path = os.path.join(
    RESULTS_DIR,
    "cross_generator_experiment_1_v2_calibrated",
    "random_forest_confusion_matrix.csv"
)

xgb_cm_path = os.path.join(
    RESULTS_DIR,
    "cross_generator_experiment_1_v2_calibrated",
    "xgboost_confusion_matrix.csv"
)

rf_cm = pd.read_csv(rf_cm_path, index_col=0)
xgb_cm = pd.read_csv(xgb_cm_path, index_col=0)

# ============================================================
# Random Forest Heatmap
# ============================================================

plt.figure(figsize=(8, 6))

sns.heatmap(
    rf_cm,
    annot=True,
    fmt="d",
    cmap="Blues"
)

plt.title("Random Forest Confusion Matrix\nGenerator-A → Generator-B v2")
plt.ylabel("True Label")
plt.xlabel("Predicted Label")

rf_heatmap_path = os.path.join(
    OUTPUT_DIR,
    "rf_confusion_matrix_heatmap.png"
)

plt.savefig(
    rf_heatmap_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Saved:", rf_heatmap_path)

# ============================================================
# XGBoost Heatmap
# ============================================================

plt.figure(figsize=(8, 6))

sns.heatmap(
    xgb_cm,
    annot=True,
    fmt="d",
    cmap="Oranges"
)

plt.title("XGBoost Confusion Matrix\nGenerator-A → Generator-B v2")
plt.ylabel("True Label")
plt.xlabel("Predicted Label")

xgb_heatmap_path = os.path.join(
    OUTPUT_DIR,
    "xgb_confusion_matrix_heatmap.png"
)

plt.savefig(
    xgb_heatmap_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Saved:", xgb_heatmap_path)

print("\nRobustness comparison generation completed.")
print("Results saved to:", OUTPUT_DIR)