import os
import json
import random
import numpy as np
import pandas as pd

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01\QKD_Generator_B"
DATA_DIR = os.path.join(BASE_DIR, "data")
META_DIR = os.path.join(BASE_DIR, "metadata")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(META_DIR, exist_ok=True)

OUTPUT_CSV = os.path.join(DATA_DIR, "qkd_generator_b_domain_shifted.csv")
OUTPUT_META = os.path.join(META_DIR, "generator_b_parameters.json")

SAMPLES_PER_CLASS = 10000
WINDOWS_PER_SESSION = 50

CLASSES = [
    "normal",
    "partial_intercept_resend",
    "detector_blind",
    "fiber_tap",
    "calibration_drift_attack"
]

hardware_profiles = {
    "H1_high_quality": {
        "detector_efficiency": (0.80, 0.90),
        "base_qber": (0.005, 0.020),
        "latency_bias": (0, 3),
        "photon_baseline": (1800, 2600)
    },
    "H2_standard": {
        "detector_efficiency": (0.65, 0.80),
        "base_qber": (0.015, 0.040),
        "latency_bias": (2, 6),
        "photon_baseline": (1600, 2400)
    },
    "H3_unstable": {
        "detector_efficiency": (0.55, 0.75),
        "base_qber": (0.020, 0.055),
        "latency_bias": (5, 12),
        "photon_baseline": (1500, 2300)
    }
}

class_ranges = {
    "normal": {
        "qber_shift": (0.000, 0.015),
        "photon_factor": (0.90, 1.08),
        "latency_shift": (0, 5),
        "abort_prob": (0.02, 0.08)
    },
    "partial_intercept_resend": {
        "qber_shift": (0.025, 0.075),
        "photon_factor": (0.78, 1.00),
        "latency_shift": (4, 14),
        "abort_prob": (0.10, 0.30)
    },
    "detector_blind": {
        "qber_shift": (0.010, 0.045),
        "photon_factor": (0.95, 1.20),
        "latency_shift": (3, 18),
        "abort_prob": (0.08, 0.25)
    },
    "fiber_tap": {
        "qber_shift": (0.005, 0.040),
        "photon_factor": (0.55, 0.88),
        "latency_shift": (5, 18),
        "abort_prob": (0.08, 0.28)
    },
    "calibration_drift_attack": {
        "qber_shift": (0.030, 0.085),
        "photon_factor": (0.72, 1.00),
        "latency_shift": (8, 22),
        "abort_prob": (0.12, 0.35)
    }
}


def sample_uniform(low, high):
    return np.random.uniform(low, high)


def generate_one_class(label, start_session_id):
    rows = []
    sessions_needed = SAMPLES_PER_CLASS // WINDOWS_PER_SESSION

    for s in range(sessions_needed):
        session_id = start_session_id + s

        profile_name = random.choice(list(hardware_profiles.keys()))
        profile = hardware_profiles[profile_name]

        detector_efficiency = sample_uniform(*profile["detector_efficiency"])
        base_qber = sample_uniform(*profile["base_qber"])
        latency_bias = sample_uniform(*profile["latency_bias"])
        base_photon_count = sample_uniform(*profile["photon_baseline"])

        fiber_length_km = sample_uniform(5, 80)
        attenuation_db_per_km = sample_uniform(0.14, 0.23)
        total_loss_db = fiber_length_km * attenuation_db_per_km

        environmental_noise = sample_uniform(0.000, 0.050)
        drift_base = sample_uniform(0.000, 0.020)
        drift_slope = sample_uniform(0.00001, 0.0008)

        for t in range(WINDOWS_PER_SESSION):
            temporal_drift = drift_base + drift_slope * t + np.random.normal(0, 0.003)
            temporal_drift = max(0, temporal_drift)

            qber_shift = sample_uniform(*class_ranges[label]["qber_shift"])
            photon_factor = sample_uniform(*class_ranges[label]["photon_factor"])
            latency_shift = sample_uniform(*class_ranges[label]["latency_shift"])
            abort_low, abort_high = class_ranges[label]["abort_prob"]

            loss_factor = 10 ** (-total_loss_db / 10)

            qber = (
                base_qber
                + qber_shift
                + temporal_drift
                + np.random.normal(0, environmental_noise / 2)
            )

            photon_count = (
                base_photon_count
                * detector_efficiency
                * loss_factor
                * photon_factor
                + np.random.normal(0, 55)
            )

            latency = (
                sample_uniform(8, 25)
                + latency_bias
                + latency_shift
                + environmental_noise * 100
                + np.random.normal(0, 2.5)
            )

            if np.random.rand() < 0.03:
                qber += sample_uniform(0.010, 0.040)
                latency += sample_uniform(3, 12)

            if label == "calibration_drift_attack":
                qber += t * sample_uniform(0.0002, 0.0008)
                latency += t * sample_uniform(0.01, 0.06)

            qber = float(np.clip(qber, 0.001, 0.180))

            # Variable lower floor avoids artificial saturation at one exact value.
            photon_count = max(photon_count, np.random.uniform(180, 320))
            photon_count = min(photon_count, 1800)
            photon_count = float(photon_count)

            latency = float(np.clip(latency, 5, 70))

            abort_probability = sample_uniform(abort_low, abort_high)

            if qber > 0.11:
                abort_probability += 0.20
            if photon_count < 450:
                abort_probability += 0.12
            if temporal_drift > 0.045:
                abort_probability += 0.10

            abort_probability = min(abort_probability, 0.85)
            abort_flag = int(np.random.rand() < abort_probability)

            rows.append({
                "session_id": session_id,
                "time_step": t,
                "hardware_profile": profile_name,
                "fiber_length_km": round(fiber_length_km, 3),
                "attenuation_db_per_km": round(attenuation_db_per_km, 4),
                "detector_efficiency": round(detector_efficiency, 4),
                "calibration_drift": round(temporal_drift, 5),
                "environmental_noise": round(environmental_noise, 5),
                "qber": round(qber, 5),
                "photon_count": round(photon_count, 2),
                "latency": round(latency, 3),
                "abort_flag": abort_flag,
                "label": label
            })

    return rows


def main():
    all_rows = []
    session_counter = 0

    for label in CLASSES:
        class_rows = generate_one_class(label, session_counter)
        all_rows.extend(class_rows)
        session_counter += SAMPLES_PER_CLASS // WINDOWS_PER_SESSION

    df = pd.DataFrame(all_rows)
    df = df.sample(frac=1, random_state=SEED).reset_index(drop=True)

    df.to_csv(OUTPUT_CSV, index=False)

    metadata = {
        "generator_name": "Generator-B: Domain-Shifted Physics-Inspired QKD Operational Simulator",
        "seed": SEED,
        "total_samples": int(df.shape[0]),
        "samples_per_class": SAMPLES_PER_CLASS,
        "windows_per_session": WINDOWS_PER_SESSION,
        "classes": CLASSES,
        "ml_features": ["qber", "photon_count", "latency", "abort_flag"],
        "traceability_features": [
            "session_id",
            "time_step",
            "hardware_profile",
            "fiber_length_km",
            "attenuation_db_per_km",
            "detector_efficiency",
            "calibration_drift",
            "environmental_noise"
        ],
        "purpose": "Cross-generator robustness validation. Train on Generator-A and test on Generator-B.",
        "note": "Metadata columns are for simulation traceability only and should not be used as ML features."
    }

    with open(OUTPUT_META, "w") as f:
        json.dump(metadata, f, indent=4)

    print("Generator-B dataset created successfully.")
    print(f"Dataset saved to: {OUTPUT_CSV}")
    print(f"Metadata saved to: {OUTPUT_META}")
    print("\nDataset shape:", df.shape)
    print("\nClass distribution:")
    print(df["label"].value_counts())
    print("\nClass-wise ML feature means:")
    print(df.groupby("label")[["qber", "photon_count", "latency", "abort_flag"]].mean())


if __name__ == "__main__":
    main()