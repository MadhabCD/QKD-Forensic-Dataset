import os
import json
import random
import numpy as np
import pandas as pd

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01\QKD_Generator_B"
DATA_DIR = os.path.join(BASE_DIR, "data")
META_DIR = os.path.join(BASE_DIR, "metadata")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(META_DIR, exist_ok=True)

OUTPUT_CSV = os.path.join(DATA_DIR, "qkd_generator_b_v2_calibrated.csv")
OUTPUT_META = os.path.join(META_DIR, "generator_b_v2_parameters.json")

SAMPLES_PER_CLASS = 10000
WINDOWS_PER_SESSION = 50

CLASSES = [
    "normal",
    "partial_intercept_resend",
    "detector_blind",
    "fiber_tap",
    "calibration_drift_attack"
]

hardware_profiles = {
    "H1_high_quality": {
        "detector_efficiency": (0.82, 0.92),
        "base_qber": (0.005, 0.020),
        "latency_bias": (0, 1.5),
        "photon_baseline": (2600, 3400)
    },
    "H2_standard": {
        "detector_efficiency": (0.70, 0.84),
        "base_qber": (0.015, 0.038),
        "latency_bias": (1, 3),
        "photon_baseline": (2400, 3200)
    },
    "H3_mildly_unstable": {
        "detector_efficiency": (0.62, 0.78),
        "base_qber": (0.020, 0.052),
        "latency_bias": (2, 5),
        "photon_baseline": (2200, 3000)
    }
}

class_ranges = {
    "normal": {
        "qber_shift": (0.000, 0.014),
        "photon_factor": (0.92, 1.08),
        "latency_shift": (0, 3),
        "abort_prob": (0.03, 0.08)
    },
    "partial_intercept_resend": {
        "qber_shift": (0.023, 0.070),
        "photon_factor": (0.82, 1.02),
        "latency_shift": (2, 7),
        "abort_prob": (0.10, 0.28)
    },
    "detector_blind": {
        "qber_shift": (0.010, 0.044),
        "photon_factor": (0.95, 1.18),
        "latency_shift": (2, 9),
        "abort_prob": (0.08, 0.23)
    },
    "fiber_tap": {
        "qber_shift": (0.006, 0.038),
        "photon_factor": (0.70, 0.92),
        "latency_shift": (3, 9),
        "abort_prob": (0.09, 0.26)
    },
    "calibration_drift_attack": {
        "qber_shift": (0.028, 0.078),
        "photon_factor": (0.78, 1.00),
        "latency_shift": (5, 12),
        "abort_prob": (0.12, 0.32)
    }
}


def sample_uniform(low, high):
    return np.random.uniform(low, high)


def generate_one_class(label, start_session_id):
    rows = []
    sessions_needed = SAMPLES_PER_CLASS // WINDOWS_PER_SESSION

    for s in range(sessions_needed):
        session_id = start_session_id + s

        profile_name = random.choice(list(hardware_profiles.keys()))
        profile = hardware_profiles[profile_name]

        detector_efficiency = sample_uniform(*profile["detector_efficiency"])
        base_qber = sample_uniform(*profile["base_qber"])
        latency_bias = sample_uniform(*profile["latency_bias"])
        base_photon_count = sample_uniform(*profile["photon_baseline"])

        fiber_length_km = sample_uniform(5, 55)
        attenuation_db_per_km = sample_uniform(0.10, 0.18)
        total_loss_db = fiber_length_km * attenuation_db_per_km

        environmental_noise = sample_uniform(0.000, 0.035)
        drift_base = sample_uniform(0.000, 0.018)
        drift_slope = sample_uniform(0.00001, 0.0006)

        for t in range(WINDOWS_PER_SESSION):
            temporal_drift = drift_base + drift_slope * t + np.random.normal(0, 0.0025)
            temporal_drift = max(0, temporal_drift)

            qber_shift = sample_uniform(*class_ranges[label]["qber_shift"])
            photon_factor = sample_uniform(*class_ranges[label]["photon_factor"])
            latency_shift = sample_uniform(*class_ranges[label]["latency_shift"])
            abort_low, abort_high = class_ranges[label]["abort_prob"]

            loss_factor = 10 ** (-total_loss_db / 10)

            qber = (
                base_qber
                + qber_shift
                + temporal_drift
                + np.random.normal(0, environmental_noise / 2)
            )

            photon_count = (
                base_photon_count
                * detector_efficiency
                * loss_factor
                * photon_factor
                + np.random.normal(0, 45)
            )

            latency = (
                sample_uniform(5, 11)
                + latency_bias
                + latency_shift
                + environmental_noise * 45
                + np.random.normal(0, 1.3)
            )

            if np.random.rand() < 0.025:
                qber += sample_uniform(0.008, 0.030)
                latency += sample_uniform(1, 5)

            if label == "calibration_drift_attack":
                qber += t * sample_uniform(0.00015, 0.00055)
                latency += t * sample_uniform(0.004, 0.025)

            qber = float(np.clip(qber, 0.001, 0.160))

            photon_count = max(photon_count, np.random.uniform(280, 420))
            photon_count = min(photon_count, 1800)
            photon_count = float(photon_count)

            latency = float(np.clip(latency, 4, 35))

            abort_probability = sample_uniform(abort_low, abort_high)

            if qber > 0.10:
                abort_probability += 0.16
            if photon_count < 500:
                abort_probability += 0.10
            if temporal_drift > 0.040:
                abort_probability += 0.08

            abort_probability = min(abort_probability, 0.80)
            abort_flag = int(np.random.rand() < abort_probability)

            rows.append({
                "session_id": session_id,
                "time_step": t,
                "hardware_profile": profile_name,
                "fiber_length_km": round(fiber_length_km, 3),
                "attenuation_db_per_km": round(attenuation_db_per_km, 4),
                "detector_efficiency": round(detector_efficiency, 4),
                "calibration_drift": round(temporal_drift, 5),
                "environmental_noise": round(environmental_noise, 5),
                "qber": round(qber, 5),
                "photon_count": round(photon_count, 2),
                "latency": round(latency, 3),
                "abort_flag": abort_flag,
                "label": label
            })

    return rows


def main():
    all_rows = []
    session_counter = 0

    for label in CLASSES:
        class_rows = generate_one_class(label, session_counter)
        all_rows.extend(class_rows)
        session_counter += SAMPLES_PER_CLASS // WINDOWS_PER_SESSION

    df = pd.DataFrame(all_rows)
    df = df.sample(frac=1, random_state=SEED).reset_index(drop=True)

    df.to_csv(OUTPUT_CSV, index=False)

    metadata = {
        "generator_name": "Generator-B v2: Calibrated Domain-Shifted QKD Operational Simulator",
        "seed": SEED,
        "total_samples": int(df.shape[0]),
        "samples_per_class": SAMPLES_PER_CLASS,
        "windows_per_session": WINDOWS_PER_SESSION,
        "classes": CLASSES,
        "ml_features": ["qber", "photon_count", "latency", "abort_flag"],
        "purpose": "Moderate cross-generator robustness validation with calibrated latency and photon-count shift.",
        "note": "Metadata columns are for traceability only and should not be used as ML features."
    }

    with open(OUTPUT_META, "w") as f:
        json.dump(metadata, f, indent=4)

    print("Generator-B v2 calibrated dataset created successfully.")
    print(f"Dataset saved to: {OUTPUT_CSV}")
    print(f"Metadata saved to: {OUTPUT_META}")
    print("\nDataset shape:", df.shape)
    print("\nClass distribution:")
    print(df["label"].value_counts())
    print("\nClass-wise ML feature means:")
    print(df.groupby("label")[["qber", "photon_count", "latency", "abort_flag"]].mean())


if __name__ == "__main__":
    main()