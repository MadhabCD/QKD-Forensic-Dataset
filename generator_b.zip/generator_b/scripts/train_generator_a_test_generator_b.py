import os
import json
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01"

GEN_A_PATH = os.path.join(
    BASE_DIR,
    "dataset final",
    "Dataset",
    "full_qkd_dataset_realistic_50000_v2.csv"
)

GEN_B_PATH = os.path.join(
    BASE_DIR,
    "QKD_Generator_B",
    "data",
    "qkd_generator_b_filtered_testset.csv"
)

RESULTS_DIR = os.path.join(
    BASE_DIR,
    "QKD_Generator_B",
    "results",
    "cross_generator_experiment_1"
)

os.makedirs(RESULTS_DIR, exist_ok=True)

CLASSES = [
    "normal",
    "partial_intercept_resend",
    "detector_blind",
    "fiber_tap"
]

FEATURES_TRAIN = ["qber", "photon_count", "latency_ms", "abort_flag"]
FEATURES_TEST = ["qber", "photon_count", "latency", "abort_flag"]

print("Loading Generator-A train dataset...")
gen_a = pd.read_csv(GEN_A_PATH)

print("Loading Generator-B filtered test dataset...")
gen_b = pd.read_csv(GEN_B_PATH)

gen_a.columns = [c.strip().lower() for c in gen_a.columns]
gen_b.columns = [c.strip().lower() for c in gen_b.columns]

gen_a = gen_a[gen_a["label"].isin(CLASSES)].copy()
gen_b = gen_b[gen_b["label"].isin(CLASSES)].copy()

print("\nGenerator-A shape:", gen_a.shape)
print("Generator-B shape:", gen_b.shape)

print("\nGenerator-A class distribution:")
print(gen_a["label"].value_counts())

print("\nGenerator-B class distribution:")
print(gen_b["label"].value_counts())

X_train = gen_a[FEATURES_TRAIN].copy()
X_train.columns = ["qber", "photon_count", "latency", "abort_flag"]

X_test = gen_b[FEATURES_TEST].copy()
X_test.columns = ["qber", "photon_count", "latency", "abort_flag"]

y_train = gen_a["label"]
y_test = gen_b["label"]

le = LabelEncoder()
le.fit(CLASSES)

y_train_enc = le.transform(y_train)
y_test_enc = le.transform(y_test)

results = {}

# =========================
# Random Forest
# =========================

print("\nTraining Random Forest...")
rf = RandomForestClassifier(
    n_estimators=300,
    random_state=42,
    class_weight="balanced",
    n_jobs=-1
)

rf.fit(X_train, y_train_enc)
rf_pred = rf.predict(X_test)

rf_cm = confusion_matrix(y_test_enc, rf_pred)
rf_report = classification_report(
    y_test_enc,
    rf_pred,
    target_names=le.classes_,
    output_dict=True,
    zero_division=0
)

results["RandomForest"] = {
    "accuracy": accuracy_score(y_test_enc, rf_pred),
    "macro_f1": f1_score(y_test_enc, rf_pred, average="macro"),
    "weighted_f1": f1_score(y_test_enc, rf_pred, average="weighted"),
    "classification_report": rf_report,
    "confusion_matrix": rf_cm.tolist()
}

pd.DataFrame(rf_cm, index=le.classes_, columns=le.classes_).to_csv(
    os.path.join(RESULTS_DIR, "random_forest_confusion_matrix.csv")
)

# =========================
# XGBoost
# =========================

print("\nTraining XGBoost...")
xgb = XGBClassifier(
    n_estimators=300,
    max_depth=5,
    learning_rate=0.05,
    subsample=0.9,
    colsample_bytree=0.9,
    objective="multi:softmax",
    num_class=len(CLASSES),
    eval_metric="mlogloss",
    random_state=42,
    n_jobs=-1
)

xgb.fit(X_train, y_train_enc)
xgb_pred = xgb.predict(X_test)

xgb_cm = confusion_matrix(y_test_enc, xgb_pred)
xgb_report = classification_report(
    y_test_enc,
    xgb_pred,
    target_names=le.classes_,
    output_dict=True,
    zero_division=0
)

results["XGBoost"] = {
    "accuracy": accuracy_score(y_test_enc, xgb_pred),
    "macro_f1": f1_score(y_test_enc, xgb_pred, average="macro"),
    "weighted_f1": f1_score(y_test_enc, xgb_pred, average="weighted"),
    "classification_report": xgb_report,
    "confusion_matrix": xgb_cm.tolist()
}

pd.DataFrame(xgb_cm, index=le.classes_, columns=le.classes_).to_csv(
    os.path.join(RESULTS_DIR, "xgboost_confusion_matrix.csv")
)

summary = pd.DataFrame([
    {
        "model": "RandomForest",
        "accuracy": results["RandomForest"]["accuracy"],
        "macro_f1": results["RandomForest"]["macro_f1"],
        "weighted_f1": results["RandomForest"]["weighted_f1"]
    },
    {
        "model": "XGBoost",
        "accuracy": results["XGBoost"]["accuracy"],
        "macro_f1": results["XGBoost"]["macro_f1"],
        "weighted_f1": results["XGBoost"]["weighted_f1"]
    }
])

summary.to_csv(
    os.path.join(RESULTS_DIR, "cross_generator_summary.csv"),
    index=False
)

with open(os.path.join(RESULTS_DIR, "cross_generator_full_results.json"), "w") as f:
    json.dump(results, f, indent=4)

print("\nCross-generator Experiment 1 completed.")
print("\nSummary:")
print(summary)

print("\nResults saved to:")
print(RESULTS_DIR)