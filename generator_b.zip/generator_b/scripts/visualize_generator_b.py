import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

BASE_DIR = r"C:\Users\madha\OneDrive\Desktop\QKD_Forensics_Project_Part_01\QKD_Generator_B"

DATA_PATH = os.path.join(
    BASE_DIR,
    "data",
    "qkd_generator_b_domain_shifted.csv"
)

RESULTS_DIR = os.path.join(BASE_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

df = pd.read_csv(DATA_PATH)

features = [
    "qber",
    "photon_count",
    "latency",
    "abort_flag"
]

# ============================================================
# QBER Distribution
# ============================================================

plt.figure(figsize=(10, 6))

for label in df["label"].unique():
    subset = df[df["label"] == label]
    plt.hist(
        subset["qber"],
        bins=50,
        alpha=0.5,
        density=True,
        label=label
    )

plt.xlabel("QBER")
plt.ylabel("Density")
plt.title("Generator-B QBER Distribution")
plt.legend()

plt.savefig(
    os.path.join(RESULTS_DIR, "qber_distribution.png"),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

# ============================================================
# Photon Count Distribution
# ============================================================

plt.figure(figsize=(10, 6))

for label in df["label"].unique():
    subset = df[df["label"] == label]
    plt.hist(
        subset["photon_count"],
        bins=50,
        alpha=0.5,
        density=True,
        label=label
    )

plt.xlabel("Photon Count")
plt.ylabel("Density")
plt.title("Generator-B Photon Count Distribution")
plt.legend()

plt.savefig(
    os.path.join(RESULTS_DIR, "photon_count_distribution.png"),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

# ============================================================
# Latency Distribution
# ============================================================

plt.figure(figsize=(10, 6))

for label in df["label"].unique():
    subset = df[df["label"] == label]
    plt.hist(
        subset["latency"],
        bins=50,
        alpha=0.5,
        density=True,
        label=label
    )

plt.xlabel("Latency")
plt.ylabel("Density")
plt.title("Generator-B Latency Distribution")
plt.legend()

plt.savefig(
    os.path.join(RESULTS_DIR, "latency_distribution.png"),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

# ============================================================
# PCA Visualization
# ============================================================

X = df[features]
y = df["label"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X_scaled)

pca_df = pd.DataFrame({
    "PC1": X_pca[:, 0],
    "PC2": X_pca[:, 1],
    "label": y
})

plt.figure(figsize=(10, 8))

for label in pca_df["label"].unique():
    subset = pca_df[pca_df["label"] == label]

    plt.scatter(
        subset["PC1"],
        subset["PC2"],
        alpha=0.4,
        s=10,
        label=label
    )

plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("Generator-B PCA Overlap Visualization")
plt.legend()

plt.savefig(
    os.path.join(RESULTS_DIR, "pca_overlap_visualization.png"),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Visualization completed.")
print("Results saved to:", RESULTS_DIR)