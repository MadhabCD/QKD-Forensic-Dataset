import argparse
import os
from datetime import datetime

import pandas as pd


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
REQUIRED_COLUMNS = ["qber", "photon_count", "latency_ms", "abort_flag", "label"]
FEATURE_COLUMNS = ["qber", "photon_count", "latency_ms", "abort_flag"]
EXPECTED_LABELS = {"normal", "partial_intercept_resend", "detector_blind", "fiber_tap"}


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="Sanity checks for QF-LOG dataset.")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to the CSV dataset file.")
    parser.add_argument("--out_dir", type=str, default="outputs_checks", help="Output folder for the report.")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Check required columns
    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}\nFound columns: {list(df.columns)}")

    # Convert features to numeric safely
    for c in FEATURE_COLUMNS:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Make label string
    df["label"] = df["label"].astype(str)

    # Basic info
    n_rows, n_cols = df.shape
    label_counts = df["label"].value_counts()

    # Missing values
    missing_summary = df[REQUIRED_COLUMNS].isna().sum()

    # Basic stats
    stats = df[FEATURE_COLUMNS].describe()

    # Simple range checks (sanity checks only)
    notes = []

    # abort_flag check
    valid_abort = df["abort_flag"].dropna().isin([0, 1]).all()
    if not valid_abort:
        notes.append("abort_flag contains values other than 0 and 1.")

    # qber check
    valid_qber = df["qber"].dropna().between(0, 1).all()
    if not valid_qber:
        notes.append("qber has values outside [0, 1]. Check generation or units.")

    # label set check
    present_labels = set(df["label"].unique().tolist())
    missing_expected = EXPECTED_LABELS - present_labels
    extra_unexpected = present_labels - EXPECTED_LABELS

    if missing_expected:
        notes.append(f"Expected labels missing: {sorted(list(missing_expected))}")
    if extra_unexpected:
        notes.append(f"Unexpected labels found: {sorted(list(extra_unexpected))}")

    # Report text
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    report_lines = []
    report_lines.append("QF-LOG Dataset Check Report")
    report_lines.append(f"Generated: {timestamp}")
    report_lines.append(f"Dataset file: {data_path}")
    report_lines.append("")
    report_lines.append(f"Rows: {n_rows}")
    report_lines.append(f"Columns: {n_cols}")
    report_lines.append("")
    report_lines.append("Label counts")
    report_lines.append(label_counts.to_string())
    report_lines.append("")
    report_lines.append("Missing values (required columns)")
    report_lines.append(missing_summary.to_string())
    report_lines.append("")
    report_lines.append("Feature statistics")
    report_lines.append(stats.to_string())
    report_lines.append("")
    report_lines.append("Notes")
    if notes:
        report_lines.extend(notes)
    else:
        report_lines.append("No major issues found in basic checks.")

    # Save report
    os.makedirs(args.out_dir, exist_ok=True)
    out_path = os.path.join(args.out_dir, "dataset_check_report.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))
        f.write("\n")

    print("Done.")
    print(f"Report saved to: {out_path}")


if __name__ == "__main__":
    main()