import argparse
import os
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="Extract simple, human-readable rules from QF-LOG (v2).")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to CSV dataset file.")
    parser.add_argument("--out_dir", type=str, default="outputs_rules", help="Output folder name.")
    parser.add_argument("--max_depth", type=int, default=4, help="Decision tree depth (smaller = simpler rules).")
    parser.add_argument("--min_leaf", type=int, default=200, help="Minimum samples per leaf (bigger = simpler rules).")
    parser.add_argument("--test_size", type=float, default=0.2, help="Test split ratio.")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed.")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    X = df[FEATURES].copy()
    y = df[LABEL_COL].copy()

    classes = sorted(y.unique().tolist())
    class_counts = y.value_counts().to_dict()

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=args.test_size,
        random_state=args.random_state,
        stratify=y
    )

    # Train interpretable model
    clf = DecisionTreeClassifier(
        max_depth=args.max_depth,
        min_samples_leaf=args.min_leaf,
        random_state=args.random_state
    )
    clf.fit(X_train, y_train)

    # Evaluate
    y_pred = clf.predict(X_test)
    report = classification_report(y_test, y_pred, labels=classes, digits=4, zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=classes)

    # Export readable rules
    rules_text = export_text(clf, feature_names=FEATURES, decimals=6)

    # Outputs
    os.makedirs(args.out_dir, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    meta_lines = [
        "QF-LOG Rule Extraction Output",
        f"Generated: {timestamp}",
        f"Dataset file: {data_path}",
        f"Rows used: {len(df)}",
        f"Features: {', '.join(FEATURES)}",
        f"Label column: {LABEL_COL}",
        f"Classes: {', '.join(classes)}",
        f"Class counts: {class_counts}",
        "",
        "Decision Tree settings",
        f"max_depth: {args.max_depth}",
        f"min_samples_leaf: {args.min_leaf}",
        f"test_size: {args.test_size}",
        f"random_state: {args.random_state}",
        "",
    ]

    rules_file = os.path.join(args.out_dir, "rules.txt")
    with open(rules_file, "w", encoding="utf-8") as f:
        f.write("\n".join(meta_lines))
        f.write("Human-readable rules\n")
        f.write(rules_text)
        f.write("\n")

    summary_file = os.path.join(args.out_dir, "rules_summary.txt")
    with open(summary_file, "w", encoding="utf-8") as f:
        f.write("\n".join(meta_lines))
        f.write("Quick evaluation on held-out test split\n")
        f.write(report + "\n")
        f.write("\nConfusion matrix (rows=true, cols=predicted)\n")
        f.write("Labels order:\n")
        f.write(", ".join(classes) + "\n\n")
        f.write(np.array2string(cm))
        f.write("\n")

    print("Done.")
    print(f"Rules saved to: {rules_file}")
    print(f"Summary saved to: {summary_file}")


if __name__ == "__main__":
    main()