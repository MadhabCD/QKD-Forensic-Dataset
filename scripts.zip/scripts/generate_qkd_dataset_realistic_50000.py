import csv
import random
import argparse


def generate_normal(n):
    rows = []
    for _ in range(n):
        rows.append({
            "qber": round(random.uniform(0.01, 0.04), 6),
            "photon_count": random.randint(930, 1070),
            "latency_ms": round(random.uniform(5.0, 6.2), 3),
            "abort_flag": 0,
            "label": "normal"
        })
    return rows


def generate_partial_intercept_resend(n):
    rows = []
    for _ in range(n):
        rows.append({
            "qber": round(random.uniform(0.03, 0.11), 6),
            "photon_count": random.randint(930, 1070),
            "latency_ms": round(random.uniform(5.4, 6.8), 3),
            "abort_flag": 0,
            "label": "partial_intercept_resend"
        })
    return rows


def generate_detector_blind(n):
    rows = []
    for _ in range(n):
        abort = 1 if random.random() < 0.8 else 0
        rows.append({
            "qber": round(random.uniform(0.03, 0.09), 6),
            "photon_count": random.randint(50, 350),
            "latency_ms": round(random.uniform(6.8, 9.2), 3),
            "abort_flag": abort,
            "label": "detector_blind"
        })
    return rows


def generate_fiber_tap(n):
    rows = []
    for _ in range(n):
        rows.append({
            "qber": round(random.uniform(0.03, 0.08), 6),
            "photon_count": random.randint(650, 950),
            "latency_ms": round(random.uniform(6.0, 7.5), 3),
            "abort_flag": 0,
            "label": "fiber_tap"
        })
    return rows


def main():
    parser = argparse.ArgumentParser(description="Generate QF-LOG realistic dataset (v2 labels).")
    parser.add_argument("--out", type=str, default="full_qkd_dataset_realistic_50000_v2.csv",
                        help="Output CSV filename.")
    parser.add_argument("--n_per_class", type=int, default=12500,
                        help="Number of samples per class.")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for reproducibility.")
    args = parser.parse_args()

    random.seed(args.seed)

    normal = generate_normal(args.n_per_class)
    partial = generate_partial_intercept_resend(args.n_per_class)
    blind = generate_detector_blind(args.n_per_class)
    fiber = generate_fiber_tap(args.n_per_class)

    full_data = normal + partial + blind + fiber
    random.shuffle(full_data)

    fieldnames = ["qber", "photon_count", "latency_ms", "abort_flag", "label"]

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(full_data)

    print("Dataset generated successfully.")
    print("File:", args.out)
    print("Total rows:", len(full_data))
    print("Seed:", args.seed)


if __name__ == "__main__":
    main()