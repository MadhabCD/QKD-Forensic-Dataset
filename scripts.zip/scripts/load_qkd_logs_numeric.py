import argparse
import os
from datetime import datetime

import pandas as pd


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"
EXPECTED_LABELS = {"normal", "partial_intercept_resend", "detector_blind", "fiber_tap"}


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="Load QF-LOG dataset and export a clean numeric ML-ready CSV.")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to the dataset CSV.")
    parser.add_argument("--out_dir", type=str, default="outputs_loader", help="Output folder.")
    parser.add_argument("--encode_labels", action="store_true", help="If set, encode labels into integers.")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric fields safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Drop rows with missing required values
    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()

    # Ensure label is string
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    # Optional label sanity check
    present_labels = set(df[LABEL_COL].unique().tolist())
    missing_expected = EXPECTED_LABELS - present_labels
    extra_unexpected = present_labels - EXPECTED_LABELS

    if missing_expected:
        print("Warning: expected labels missing:", sorted(list(missing_expected)))
    if extra_unexpected:
        print("Warning: unexpected labels found:", sorted(list(extra_unexpected)))

    # Output dataframe
    out_df = df[FEATURES + [LABEL_COL]].copy()

    os.makedirs(args.out_dir, exist_ok=True)

    # Optional label encoding
    if args.encode_labels:
        unique_labels = sorted(out_df[LABEL_COL].unique().tolist())
        label_to_id = {lab: i for i, lab in enumerate(unique_labels)}
        out_df["label_id"] = out_df[LABEL_COL].map(label_to_id).astype(int)

        mapping_lines = ["Label mapping (label -> id)"]
        for lab in unique_labels:
            mapping_lines.append(f"{lab} -> {label_to_id[lab]}")

        with open(os.path.join(args.out_dir, "label_mapping.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(mapping_lines) + "\n")

    # Save ML-ready CSV
    out_path = os.path.join(args.out_dir, "qflog_numeric.csv")
    out_df.to_csv(out_path, index=False)

    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    print("QF-LOG loader finished.")
    print(f"Time: {timestamp}")
    print(f"Input: {data_path}")
    print(f"Rows exported: {len(out_df)}")
    print(f"Saved: {out_path}")
    if args.encode_labels:
        print("Saved: outputs_loader/label_mapping.txt")


if __name__ == "__main__":
    main()