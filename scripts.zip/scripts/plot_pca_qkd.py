import argparse
import os
from datetime import datetime

import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

import matplotlib.pyplot as plt


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="PCA plot for QF-LOG dataset (v2).")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to dataset CSV.")
    parser.add_argument("--out_dir", type=str, default="outputs_plots", help="Output folder.")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed (not critical for PCA).")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    X = df[FEATURES].values
    y = df[LABEL_COL].values

    # Standardize
    X_scaled = StandardScaler().fit_transform(X)

    # PCA
    pca = PCA(n_components=2, random_state=args.random_state)
    X_pca = pca.fit_transform(X_scaled)

    pca_df = pd.DataFrame({
        "pc1": X_pca[:, 0],
        "pc2": X_pca[:, 1],
        "label": y
    })

    os.makedirs(args.out_dir, exist_ok=True)

    # Save PCA points
    csv_out = os.path.join(args.out_dir, "pca_qflog.csv")
    pca_df.to_csv(csv_out, index=False)

    # Plot
    plt.figure(figsize=(8, 6))
    labels_order = sorted(pca_df["label"].unique().tolist())

    for lab in labels_order:
        sub = pca_df[pca_df["label"] == lab]
        plt.scatter(sub["pc1"], sub["pc2"], s=10, alpha=0.7, label=lab)

    var1 = pca.explained_variance_ratio_[0] * 100
    var2 = pca.explained_variance_ratio_[1] * 100
    plt.xlabel(f"PC1 ({var1:.2f}%)")
    plt.ylabel(f"PC2 ({var2:.2f}%)")
    plt.title("QF-LOG PCA Projection (v2)")
    plt.legend(markerscale=2, fontsize=8)
    plt.tight_layout()

    img_out = os.path.join(args.out_dir, "pca_qflog.png")
    plt.savefig(img_out, dpi=300)
    plt.close()

    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    print("Done.")
    print(f"Time: {timestamp}")
    print(f"Saved plot: {img_out}")
    print(f"Saved PCA points: {csv_out}")


if __name__ == "__main__":
    main()