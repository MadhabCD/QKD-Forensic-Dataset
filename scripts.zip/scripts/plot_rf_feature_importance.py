import argparse
import os
from datetime import datetime

import pandas as pd
import matplotlib.pyplot as plt


DEFAULT_IMPORTANCE_CSV = os.path.join("outputs_rf", "rf_feature_importance.csv")


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="Plot Random Forest feature importance for QF-LOG.")
    parser.add_argument("--importance_csv", type=str, default=DEFAULT_IMPORTANCE_CSV, help="Path to rf_feature_importance.csv")
    parser.add_argument("--out_dir", type=str, default="outputs_plots", help="Output folder for plots.")
    parser.add_argument("--top_n", type=int, default=20, help="Number of top features to plot.")
    args = parser.parse_args()

    imp_path = args.importance_csv
    if not os.path.exists(imp_path):
        imp_path = find_existing_path([
            args.importance_csv,
            os.path.join("outputs_rf", "rf_feature_importance.csv"),
            "rf_feature_importance.csv"
        ])

    if not imp_path:
        raise FileNotFoundError(
            "Feature importance CSV not found. Run train_rf_realistic.py first, or provide --importance_csv."
        )

    imp_df = pd.read_csv(imp_path)

    # Validate columns
    if "feature" not in imp_df.columns or "importance" not in imp_df.columns:
        raise ValueError(f"Expected columns: feature, importance. Found: {list(imp_df.columns)}")

    imp_df = imp_df.sort_values("importance", ascending=False).head(args.top_n)

    os.makedirs(args.out_dir, exist_ok=True)

    # Plot
    plt.figure(figsize=(8, 5))
    plt.bar(imp_df["feature"], imp_df["importance"])
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Importance")
    plt.title("QF-LOG Random Forest Feature Importance")
    plt.tight_layout()

    out_img = os.path.join(args.out_dir, "rf_feature_importance.png")
    plt.savefig(out_img, dpi=300)
    plt.close()

    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    print("Done.")
    print(f"Time: {timestamp}")
    print(f"Read: {imp_path}")
    print(f"Saved plot: {out_img}")


if __name__ == "__main__":
    main()