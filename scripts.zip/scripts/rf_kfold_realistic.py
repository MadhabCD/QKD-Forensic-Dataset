import argparse
import os
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="5-fold cross validation for Random Forest on QF-LOG (v2).")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to dataset CSV.")
    parser.add_argument("--out_dir", type=str, default="outputs_rf", help="Output folder.")
    parser.add_argument("--k", type=int, default=5, help="Number of folds.")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed.")
    parser.add_argument("--n_estimators", type=int, default=300, help="Number of trees.")
    parser.add_argument("--max_depth", type=int, default=None, help="Max depth (None = unlimited).")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric features safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    X = df[FEATURES].values
    y = df[LABEL_COL].values

    skf = StratifiedKFold(n_splits=args.k, shuffle=True, random_state=args.random_state)

    fold_acc = []
    fold_num = 1

    for train_idx, test_idx in skf.split(X, y):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]

        clf = RandomForestClassifier(
            n_estimators=args.n_estimators,
            random_state=args.random_state,
            n_jobs=-1,
            max_depth=args.max_depth
        )
        clf.fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        fold_acc.append(acc)

        print(f"Fold {fold_num} accuracy: {acc:.4f}")
        fold_num += 1

    mean_acc = float(np.mean(fold_acc))
    std_acc = float(np.std(fold_acc, ddof=1))  # sample standard deviation

    os.makedirs(args.out_dir, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    out_path = os.path.join(args.out_dir, "rf_kfold_report.txt")

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("QF-LOG Random Forest 5-Fold Cross Validation Report\n")
        f.write(f"Generated: {timestamp}\n")
        f.write(f"Dataset file: {data_path}\n")
        f.write(f"Rows used: {len(df)}\n")
        f.write(f"Features: {', '.join(FEATURES)}\n")
        f.write(f"Folds: {args.k}\n")
        f.write(f"Random state: {args.random_state}\n")
        f.write(f"n_estimators: {args.n_estimators}\n")
        f.write(f"max_depth: {args.max_depth}\n")
        f.write("\nFold accuracies\n")
        for i, a in enumerate(fold_acc, start=1):
            f.write(f"Fold {i}: {a:.6f}\n")
        f.write("\n")
        f.write(f"Mean accuracy: {mean_acc:.6f}\n")
        f.write(f"Std accuracy (sample, ddof=1): {std_acc:.6f}\n")

    print("\nSummary")
    print(f"Mean accuracy: {mean_acc:.4f}")
    print(f"Std accuracy:  {std_acc:.4f} (sample std, ddof=1)")
    print(f"Saved report: {out_path}")


if __name__ == "__main__":
    main()