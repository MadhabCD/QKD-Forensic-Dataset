import argparse
import os
from datetime import datetime

import pandas as pd
from sklearn.metrics import classification_report, accuracy_score


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def rule_predict(row):
    """
    Simple baseline rules.
    These rules are only a forensic baseline, not a replacement for ML models.

    Uses:
    - low photon_count as fiber loss/tap signal
    - abort_flag as strong suspicious indicator
    - higher qber and latency patterns for other attacks
    """
    qber = row["qber"]
    photons = row["photon_count"]
    latency = row["latency_ms"]
    abort = row["abort_flag"]

    # fiber tap: strong loss signal
    if photons <= 1800:
        return "fiber_tap"

    # abort indicates attack-like condition
    if abort == 1:
        # strong disturbance pattern
        if qber >= 0.18 or latency >= 8.0:
            return "detector_blind"
        return "partial_intercept_resend"

    # moderate qber without abort can still indicate partial intercept-resend
    if qber >= 0.08:
        return "partial_intercept_resend"

    return "normal"


def main():
    parser = argparse.ArgumentParser(description="Rule-based baseline detector for QF-LOG.")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to CSV dataset file.")
    parser.add_argument("--out_dir", type=str, default="outputs_rules", help="Output folder.")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric fields safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    # Predict
    y_true = df[LABEL_COL].tolist()
    y_pred = [rule_predict(row) for _, row in df.iterrows()]

    # Metrics
    acc = accuracy_score(y_true, y_pred)
    labels_order = sorted(df[LABEL_COL].unique().tolist())
    report = classification_report(y_true, y_pred, labels=labels_order, digits=4, zero_division=0)

    # Save report
    os.makedirs(args.out_dir, exist_ok=True)
    out_path = os.path.join(args.out_dir, "rule_based_report.txt")

    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    lines = []
    lines.append("QF-LOG Rule-Based Detector Report")
    lines.append(f"Generated: {timestamp}")
    lines.append(f"Dataset file: {data_path}")
    lines.append("")
    lines.append(f"Rows evaluated: {len(df)}")
    lines.append(f"Accuracy: {acc:.4f}")
    lines.append("")
    lines.append("Classification report")
    lines.append(report)
    lines.append("")
    lines.append("Rule thresholds used")
    lines.append("fiber_tap: photon_count <= 1800")
    lines.append("detector_blind: abort_flag=1 and (qber >= 0.18 or latency_ms >= 8.0)")
    lines.append("partial_intercept_resend: abort_flag=1 or qber >= 0.08")
    lines.append("normal: otherwise")

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print("Done.")
    print(f"Report saved to: {out_path}")


if __name__ == "__main__":
    main()