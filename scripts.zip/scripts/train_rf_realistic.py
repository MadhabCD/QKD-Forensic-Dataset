import argparse
import os
from datetime import datetime

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="Train Random Forest on QF-LOG dataset (v2).")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to dataset CSV.")
    parser.add_argument("--out_dir", type=str, default="outputs_rf", help="Output folder.")
    parser.add_argument("--test_size", type=float, default=0.2, help="Test split ratio.")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed.")
    parser.add_argument("--n_estimators", type=int, default=300, help="Number of trees.")
    parser.add_argument("--max_depth", type=int, default=None, help="Max depth (None = unlimited).")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric features safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    X = df[FEATURES].copy()
    y = df[LABEL_COL].copy()

    # Split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=args.test_size,
        random_state=args.random_state,
        stratify=y
    )

    # Train RF
    clf = RandomForestClassifier(
        n_estimators=args.n_estimators,
        random_state=args.random_state,
        n_jobs=-1,
        max_depth=args.max_depth
    )
    clf.fit(X_train, y_train)

    # Evaluate
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    labels_order = sorted(y.unique().tolist())
    report = classification_report(y_test, y_pred, labels=labels_order, digits=4, zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=labels_order)

    # Feature importance
    importances = list(zip(FEATURES, clf.feature_importances_))
    importances_sorted = sorted(importances, key=lambda x: x[1], reverse=True)

    # Save outputs
    os.makedirs(args.out_dir, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    report_path = os.path.join(args.out_dir, "rf_report.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("QF-LOG Random Forest Training Report\n")
        f.write(f"Generated: {timestamp}\n")
        f.write(f"Dataset file: {data_path}\n")
        f.write(f"Rows used: {len(df)}\n")
        f.write(f"Features: {', '.join(FEATURES)}\n")
        f.write(f"Test size: {args.test_size}\n")
        f.write(f"Random state: {args.random_state}\n")
        f.write(f"n_estimators: {args.n_estimators}\n")
        f.write(f"max_depth: {args.max_depth}\n")
        f.write("\n")
        f.write(f"Accuracy: {acc:.4f}\n\n")
        f.write("Classification report\n")
        f.write(report + "\n")
        f.write("\nConfusion matrix (rows=true, cols=predicted)\n")
        f.write("Labels order:\n")
        f.write(", ".join(labels_order) + "\n\n")
        f.write(str(cm) + "\n")
        f.write("\nFeature importance (descending)\n")
        for name, val in importances_sorted:
            f.write(f"{name}: {val:.6f}\n")

    # Save feature importance CSV
    imp_path = os.path.join(args.out_dir, "rf_feature_importance.csv")
    pd.DataFrame(importances_sorted, columns=["feature", "importance"]).to_csv(imp_path, index=False)

    print("Done.")
    print(f"Accuracy: {acc:.4f}")
    print(f"Saved report: {report_path}")
    print(f"Saved feature importance: {imp_path}")


if __name__ == "__main__":
    main()