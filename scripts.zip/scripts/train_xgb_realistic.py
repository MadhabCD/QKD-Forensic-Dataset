import argparse
import os
from datetime import datetime

import pandas as pd
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split

from xgboost import XGBClassifier


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="Train XGBoost on QF-LOG dataset (v2).")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to dataset CSV.")
    parser.add_argument("--out_dir", type=str, default="outputs_xgb", help="Output folder.")
    parser.add_argument("--test_size", type=float, default=0.2, help="Test split ratio.")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed.")
    parser.add_argument("--n_estimators", type=int, default=400, help="Number of boosting rounds.")
    parser.add_argument("--max_depth", type=int, default=5, help="Tree depth.")
    parser.add_argument("--learning_rate", type=float, default=0.08, help="Learning rate.")
    parser.add_argument("--subsample", type=float, default=0.9, help="Row subsample.")
    parser.add_argument("--colsample_bytree", type=float, default=0.9, help="Column subsample.")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric features safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    X = df[FEATURES].copy()
    y = df[LABEL_COL].copy()

    # Encode labels to integers for XGBoost
    labels_order = sorted(y.unique().tolist())
    label_to_id = {lab: i for i, lab in enumerate(labels_order)}
    id_to_label = {i: lab for lab, i in label_to_id.items()}
    y_id = y.map(label_to_id).astype(int)

    # Split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_id,
        test_size=args.test_size,
        random_state=args.random_state,
        stratify=y_id
    )

    # Train XGBoost
    clf = XGBClassifier(
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        learning_rate=args.learning_rate,
        subsample=args.subsample,
        colsample_bytree=args.colsample_bytree,
        objective="multi:softprob",
        num_class=len(labels_order),
        random_state=args.random_state,
        n_jobs=-1,
        eval_metric="mlogloss"
    )
    clf.fit(X_train, y_train)

    # Evaluate
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    # Convert back to label names for report
    y_test_lab = [id_to_label[int(i)] for i in y_test]
    y_pred_lab = [id_to_label[int(i)] for i in y_pred]

    report = classification_report(y_test_lab, y_pred_lab, labels=labels_order, digits=4, zero_division=0)
    cm = confusion_matrix(y_test_lab, y_pred_lab, labels=labels_order)

    # Feature importance (gain-based importance in XGBoost)
    # Note: get_score uses feature names like f0, f1, ... unless we map them
    score = clf.get_booster().get_score(importance_type="gain")
    # Map f0,f1,... to actual feature names
    gain_map = {}
    for k, v in score.items():
        if k.startswith("f"):
            idx = int(k[1:])
            if 0 <= idx < len(FEATURES):
                gain_map[FEATURES[idx]] = v
    # Ensure all features present
    for f in FEATURES:
        gain_map.setdefault(f, 0.0)

    imp_df = pd.DataFrame(
        sorted(gain_map.items(), key=lambda x: x[1], reverse=True),
        columns=["feature", "gain_importance"]
    )

    # Save outputs
    os.makedirs(args.out_dir, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    report_path = os.path.join(args.out_dir, "xgb_report.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("QF-LOG XGBoost Training Report\n")
        f.write(f"Generated: {timestamp}\n")
        f.write(f"Dataset file: {data_path}\n")
        f.write(f"Rows used: {len(df)}\n")
        f.write(f"Features: {', '.join(FEATURES)}\n")
        f.write(f"Test size: {args.test_size}\n")
        f.write(f"Random state: {args.random_state}\n")
        f.write("\nXGBoost parameters\n")
        f.write(f"n_estimators: {args.n_estimators}\n")
        f.write(f"max_depth: {args.max_depth}\n")
        f.write(f"learning_rate: {args.learning_rate}\n")
        f.write(f"subsample: {args.subsample}\n")
        f.write(f"colsample_bytree: {args.colsample_bytree}\n")
        f.write("\n")
        f.write(f"Accuracy: {acc:.4f}\n\n")
        f.write("Classification report\n")
        f.write(report + "\n")
        f.write("\nConfusion matrix (rows=true, cols=predicted)\n")
        f.write("Labels order:\n")
        f.write(", ".join(labels_order) + "\n\n")
        f.write(str(cm) + "\n")
        f.write("\nLabel mapping (label -> id)\n")
        for lab in labels_order:
            f.write(f"{lab} -> {label_to_id[lab]}\n")

    imp_path = os.path.join(args.out_dir, "xgb_feature_importance_gain.csv")
    imp_df.to_csv(imp_path, index=False)

    print("Done.")
    print(f"Accuracy: {acc:.4f}")
    print(f"Saved report: {report_path}")
    print(f"Saved feature importance: {imp_path}")


if __name__ == "__main__":
    main()