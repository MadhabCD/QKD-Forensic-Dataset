import argparse
import os
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold

from xgboost import XGBClassifier


DEFAULT_DATASET = "full_qkd_dataset_realistic_50000_v2.csv"
FEATURES = ["qber", "photon_count", "latency_ms", "abort_flag"]
LABEL_COL = "label"


def find_existing_path(candidate_paths):
    for p in candidate_paths:
        if p and os.path.exists(p):
            return p
    return None


def main():
    parser = argparse.ArgumentParser(description="5-fold cross validation for XGBoost on QF-LOG (v2).")
    parser.add_argument("--data", type=str, default=DEFAULT_DATASET, help="Path to dataset CSV.")
    parser.add_argument("--out_dir", type=str, default="outputs_xgb", help="Output folder.")
    parser.add_argument("--k", type=int, default=5, help="Number of folds.")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed.")

    parser.add_argument("--n_estimators", type=int, default=400, help="Number of boosting rounds.")
    parser.add_argument("--max_depth", type=int, default=5, help="Tree depth.")
    parser.add_argument("--learning_rate", type=float, default=0.08, help="Learning rate.")
    parser.add_argument("--subsample", type=float, default=0.9, help="Row subsample.")
    parser.add_argument("--colsample_bytree", type=float, default=0.9, help="Column subsample.")
    args = parser.parse_args()

    data_path = args.data
    if not os.path.exists(data_path):
        data_path = find_existing_path([
            args.data,
            os.path.join("data", args.data),
            os.path.join("data", DEFAULT_DATASET),
            DEFAULT_DATASET
        ])

    if not data_path:
        raise FileNotFoundError(
            "Dataset CSV not found. Provide --data path or place the file in the repo root or data/ folder."
        )

    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURES + [LABEL_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}\nFound columns: {list(df.columns)}")

    # Convert numeric features safely
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=FEATURES + [LABEL_COL]).copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str)

    X = df[FEATURES].values
    y = df[LABEL_COL].values

    # Encode labels to integers
    labels_order = sorted(df[LABEL_COL].unique().tolist())
    label_to_id = {lab: i for i, lab in enumerate(labels_order)}
    y_id = np.array([label_to_id[str(l)] for l in y], dtype=int)

    skf = StratifiedKFold(n_splits=args.k, shuffle=True, random_state=args.random_state)

    fold_acc = []
    fold_num = 1

    for train_idx, test_idx in skf.split(X, y_id):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y_id[train_idx], y_id[test_idx]

        clf = XGBClassifier(
            n_estimators=args.n_estimators,
            max_depth=args.max_depth,
            learning_rate=args.learning_rate,
            subsample=args.subsample,
            colsample_bytree=args.colsample_bytree,
            objective="multi:softprob",
            num_class=len(labels_order),
            random_state=args.random_state,
            n_jobs=-1,
            eval_metric="mlogloss"
        )
        clf.fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        fold_acc.append(acc)

        print(f"Fold {fold_num} accuracy: {acc:.4f}")
        fold_num += 1

    mean_acc = float(np.mean(fold_acc))
    std_acc = float(np.std(fold_acc, ddof=1))  # sample standard deviation

    os.makedirs(args.out_dir, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    out_path = os.path.join(args.out_dir, "xgb_kfold_report.txt")

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("QF-LOG XGBoost 5-Fold Cross Validation Report\n")
        f.write(f"Generated: {timestamp}\n")
        f.write(f"Dataset file: {data_path}\n")
        f.write(f"Rows used: {len(df)}\n")
        f.write(f"Features: {', '.join(FEATURES)}\n")
        f.write(f"Folds: {args.k}\n")
        f.write(f"Random state: {args.random_state}\n")
        f.write("\nXGBoost parameters\n")
        f.write(f"n_estimators: {args.n_estimators}\n")
        f.write(f"max_depth: {args.max_depth}\n")
        f.write(f"learning_rate: {args.learning_rate}\n")
        f.write(f"subsample: {args.subsample}\n")
        f.write(f"colsample_bytree: {args.colsample_bytree}\n")
        f.write("\nFold accuracies\n")
        for i, a in enumerate(fold_acc, start=1):
            f.write(f"Fold {i}: {a:.6f}\n")
        f.write("\n")
        f.write(f"Mean accuracy: {mean_acc:.6f}\n")
        f.write(f"Std accuracy (sample, ddof=1): {std_acc:.6f}\n")
        f.write("\nLabel mapping (label -> id)\n")
        for lab in labels_order:
            f.write(f"{lab} -> {label_to_id[lab]}\n")

    print("\nSummary")
    print(f"Mean accuracy: {mean_acc:.4f}")
    print(f"Std accuracy:  {std_acc:.4f} (sample std, ddof=1)")
    print(f"Saved report: {out_path}")


if __name__ == "__main__":
    main()